# Check for Menu Bar and the elements inside menu bar

Status: Done

1. Check whether Menu bar is present if so go to step 2
2. Check each element in the menu Bar