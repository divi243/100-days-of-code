# img icons on the page - ONLY DISPLAYED

Status: Done

identify the img icons after search bar

ONLY displayed ones

verify the img and count