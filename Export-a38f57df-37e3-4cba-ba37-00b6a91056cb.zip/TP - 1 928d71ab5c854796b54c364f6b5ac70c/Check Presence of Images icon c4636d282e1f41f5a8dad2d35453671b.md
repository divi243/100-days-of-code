# Check Presence of Images icon

Status: Done
site: https://www.guru99.com/

verify whether the icons are present - 9 icons, they all are images