# Column List on the page

Status: Done

1 . Identify the Column list of items on the page

2. Verify the column items and the text