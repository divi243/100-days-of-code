# Mouse Hover action on menu

Status: Done

1. Go to menu item and hover the mouse over the menu list item
2. The drop down second menu should come up 
3. Verify the sublist item and click action should work