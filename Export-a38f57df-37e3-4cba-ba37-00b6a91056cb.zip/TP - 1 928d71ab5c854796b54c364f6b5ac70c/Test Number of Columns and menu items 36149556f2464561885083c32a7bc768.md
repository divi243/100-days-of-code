# Test Number of Columns and menu items

Status: Done

1. count number of columns
2. count number of sub columns within the column