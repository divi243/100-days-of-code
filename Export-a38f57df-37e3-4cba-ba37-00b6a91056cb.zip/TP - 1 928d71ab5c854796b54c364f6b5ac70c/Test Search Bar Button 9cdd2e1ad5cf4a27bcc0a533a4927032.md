# Test Search Bar/Button

Status: Done

1. identify search bar
2. identify the search button
3. Test the click event on search bar
4. Test searching