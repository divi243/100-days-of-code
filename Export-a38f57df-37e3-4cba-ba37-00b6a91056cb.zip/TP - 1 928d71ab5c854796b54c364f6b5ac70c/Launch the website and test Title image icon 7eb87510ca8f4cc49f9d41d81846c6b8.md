# Launch the website and test Title image icon

Status: Done
site: https://www.guru99.com/

Started with testing for GURU99 WEBSITE, 

1. Check for GURU99 TITLE IMAGE - It is an image link which do not have any link text so we make use of CSS selector or xpath to identify the element and then get the title
2. To check whether the image is  present

WebElement title = driver.findElement(By.xpath("/html/body/div[2]/section[2]/div/div/div[1]/div/a/img"));
Assert.assertEquals( title.getAttribute("src"), "[https://www.guru99.com/images/logo/logo_v1.png](https://www.guru99.com/images/logo/logo_v1.png)");